<?php
$menu['register']= array(
    //'class' => "header",
    //'title' => 'ลงทะเบียนกิจกรรม',
    //'cond' => true,
    //'bullet' => 'nature_people',
   // 'color' => 'col-green',
    //'url' => 'main/register/form/general',
    /*'item' => array(
        'billing' => array('bullet' => '',
            'title' => 'ค่าบริการ',
            'url' => 'main/admin/billing/manage',
            'cond' => true,
            ),
        'coupon' => array('bullet' => '',
                'title' => 'คูปอง',
                'url' => 'main/admin/coupon/view',
                'cond' => true,
                ),
        ),*/
        
    );