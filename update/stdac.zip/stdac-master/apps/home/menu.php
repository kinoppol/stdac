<?php

$menu['home']= array(
    'class' => "header",
    'title' => 'ภาพรวม',
    'cond' => true,
    'bullet' => 'bubble_chart',
    'color'=> 'col-green',
    'url' => 'main/home/dashboard/view',
    /*'item' => array(
        'doc' => array('bullet' => '',
            'title' => 'เดชบอร์ด',
            'url' => 'main/home/dashboard/view',
            'cond' => true,
            ),       
             'wallet' => array('bullet' => '',
            'title' => 'เติมเงิน',
            'url' => 'main/home/wallet/manage',
            'cond' => true,
            ),
        ),
        */
    );
