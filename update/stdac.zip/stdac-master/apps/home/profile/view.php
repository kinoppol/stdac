
<?php
load_fun('table');
load_fun('datatable');
$title = "Home";
$subtitle = "หน้าหลัก";
load_fun('folder');
load_fun('table');

print sHeader($title,$subtitle);
?>