<?php
    $title="คูปอง";
?>
  <div class="container-fluid">
            <div class="block-header">
                <h2>DASHBOARD</h2>
            </div>

            
            
            <div id="createNewWallet" class="row clearfix">            
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="body">
                            พิมพ์คูปอง <a href="<?php print site_url('ajax/admin/coupon/print'); ?>" target="_blank" class="btn btn-primary" ><i class="material-icons">print</i> พิมพ์</a>
                        </div>
                    </div>
                </div>
            </div>
